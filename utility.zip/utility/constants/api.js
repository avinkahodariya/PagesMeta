export const APIPath = {
   baseURL: "/api",
   applications: "applications",
   page: "pages",
   meta: "meta",
};
