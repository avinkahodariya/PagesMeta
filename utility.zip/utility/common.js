export class CommonUtility  {
    static isNull=(obj) => {
        return obj === undefined || obj === null
    }
}